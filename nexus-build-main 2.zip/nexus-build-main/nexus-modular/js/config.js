export const CONFIG = {
    SYSTEM_PASSWORD: "nexus", // <--- CHANGE PASSWORD HERE
    PROVIDERS: {
        groq: { url: "..." }
    }
};
